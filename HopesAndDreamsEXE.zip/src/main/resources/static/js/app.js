var app = angular.module('myApp',[]);

app.value("UrlHeader", "http://localhost:8080/mavenAngularProject/");

